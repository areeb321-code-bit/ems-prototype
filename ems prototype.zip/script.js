const events = [
  {
    title: "Tech Seminar",
    date: "20 Jan 2026",
    location: "Auditorium",
    image: "images/tech.jpg"
  },
  {
    title: "Sports Week",
    date: "25 Jan 2026",
    location: "Sports Ground",
    image: "images/sports.jpg"
  },
  {
    title: "Web Development Workshop",
    date: "30 Jan 2026",
    location: "Lab 3",
    image: "images/workshop.jpg"
  },
  {
    title: "Music Night",
    date: "2 Feb 2026",
    location: "Open Ground",
    image: "images/music.jpg"
  },
  {
    title: "Business Seminar",
    date: "5 Feb 2026",
    location: "Conference Hall",
    image: "images/seminar.jpg"
  }
];

const eventContainer = document.getElementById("event-list");

if (eventContainer) {
  events.forEach(event => {
    eventContainer.innerHTML += `
      <div class="card">
        <img src="${event.image}">
        <div class="card-body">
          <h3>${event.title}</h3>
          <p>📅 ${event.date}</p>
          <p>📍 ${event.location}</p>
          <a href="event-details.html" class="btn">View Details</a>
        </div>
      </div>
    `;
  });
}
